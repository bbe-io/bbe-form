<template>
    <div :class="wrapperClass">
        <label :class="labelClass" :for="id">{{label}}</label>
        <input
            ref="input"
            :id="id" :name="name"
            :value="value" :type="type"
            @input="change"
            :class="inputClass" :placeholder="placeholder"/>
        <small :class="errorClass"
               v-if="form.errors.has(name)"
               v-text="form.errors.get(name)"
        ></small>
    </div>
</template>

<script>
    export default {
        name : 'bbe-text-input',
        props: {
            form: {
                type: Object
            },
            type: {
                type: String,
                default: 'text'
            },
            labelClass: {
                type: String,
                default :''
            },
            label: {
                type: String
            },
            inputClass: {
                type: String,
                default :'form-control'
            },
            id: {
                type: String,
                default :''
            },
            name: {
                type: String,
                default() {
                    return this.id;
                }
            },
            value: {
                type: String,
                required: true
            },
            errorClass: {
                type: String,
                default :'form-text text-warning'
            },
            placeholder: {
                type: String,
                default() {
                    return this.label;
                }
            }
        },
        computed: {
            wrapperClass() {
                if(!this.$el) {
                    return 'form-group';
                }
                return this.$el.classList ? '' : 'form-group';
            }
        },
        methods: {
            change() {
                this.$emit('input', this.$refs.input.value)
            }
        },
        mounted() {
            console.log('Component mounted.', this.$el)
        }
    }
</script>
